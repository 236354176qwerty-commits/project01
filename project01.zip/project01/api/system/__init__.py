from api.maintenance import maintenance_bp
from api.dashboard import system_bp

__all__ = [
    'maintenance_bp',
    'system_bp',
]
