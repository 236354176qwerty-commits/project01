#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
武术赛事管理系统 - 工具函数包
"""

from .helpers import *
from .decorators import *

__version__ = '1.0.0'
__author__ = '武术赛事管理团队'
